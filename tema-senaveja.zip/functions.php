<?php

function senaveja_theme_support() {
	add_theme_support( 'title-tag' );
}

add_action( 'after_setup_theme', 'senaveja_theme_support' );

function senaveja_register_styles() {

	$theme_version = wp_get_theme()->get( 'Version' );

	wp_enqueue_style( 'senaveja-grid-system', get_template_directory_uri() . '/grid-system.css', array(), $theme_version );
	wp_enqueue_style( 'senaveja-style', get_stylesheet_uri(), array( 'senaveja-grid-system' ), $theme_version );

}

add_action( 'wp_enqueue_scripts', 'senaveja_register_styles' );

function meu_tema_enqueue_scripts() {
	wp_enqueue_script( 'scripts', get_template_directory_uri() . "/assets/js/scripts.js" );
	wp_localize_script( 'scripts', 'ajax_object', array(
		'ajax_url' =>
			admin_url( 'admin-ajax.php' )
	) );
}

add_action( 'wp_enqueue_scripts', 'meu_tema_enqueue_scripts' );
function sena_veja_menus() {

	$locations = array(
		'primary' => __( 'Menu principal', 'sena_veja' ),
	);

	register_nav_menus( $locations );
}

add_action( 'init', 'sena_veja_menus' );

function senaveja_load_post( $page = 1, $ajax = false ) {
	$return        = new stdClass();
	$return->posts = array();
	$return->total = 0;
	$number        = 10;
	$url           = 'https://public-api.wordpress.com/rest/v1.1/sites/109720969/posts?number=' . ( $number + 1 ) . '&page=' . $page;

	$request = wp_remote_get( $url, array(
		'timeout' => 30,
	) );

	$body = wp_remote_retrieve_body( $request );
	$data = json_decode( $body );

	$return->total = count( $data->posts );

	if ( $return->total > $number ) {
		$return->total = $number;
		$return->next  = $page + 1;
	}

	foreach ( $data->posts as $key => $row ) {
		$post       = new stdClass();
		$categories = array();

		foreach ( $row->terms->category as $category ) {
			$categories[] = $category->name;
		}

		$post->ID       = $row->ID;
		$post->URL      = $row->URL;
		$post->title    = $row->title;
		$post->image    = ! empty( $row->featured_image ) ? $row->featured_image : $row->post_thumbnail->guid;
		$post->category = implode( ', ', $categories );
		$post->date     = date_i18n( get_option( 'links_updated_date_format' ), strtotime( $row->date ) );


		$return->posts[] = $post;
	}

	return $return;
}

function senaveja_load_post_ajaxd() {
	$return = senaveja_load_post( $_POST['page'], true );
	echo json_encode( $return );
	wp_die();
}

add_action( 'wp_ajax_senaveja_load_post_ajaxd', 'senaveja_load_post_ajaxd' );
add_action( 'wp_ajax_nopriv_senaveja_load_post_ajaxd', 'senaveja_load_post_ajaxd' );