const result = (data) => {
    let item = document.querySelector('.load-more a');
    data = JSON.parse(data);
    if (!data.next) {
        item.remove();
        return false;
    }
    item.classList.remove('loading');
    item.dataset.next = data.next;

    for (let i in data.posts) {
        let post = data.posts[i];
        let template = document.querySelector('.post').cloneNode(true);
        template.className = '';
        template.classList.add('post');
        template.classList.add('post-' + post.ID);
        template.querySelector('.thumbnail').src = post.image;
        template.querySelector('.thumbnail').alt = post.title;
        template.querySelector('.thumbnail').title = post.title;
        template.querySelector('h2').innerHTML = post.title;
        template.querySelector('a').href = post.URL;
        template.querySelector('.datetime').innerHTML = post.date;
        template.querySelector('.category').innerHTML = post.category;

        document.querySelector('.post-list').append(template)
    }
};
const ajax = (page) => {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            result(this.responseText);
        }
    };
    xhttp.open('POST', ajax_object.ajax_url, true);
    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhttp.send('action=senaveja_load_post_ajaxd&page=' + page);
};
window.addEventListener('load', function () {
    document.querySelector('.load-more a').addEventListener('click', function () {
        if (this.dataset.next) {
            let page = this.dataset.next;
            this.dataset.next = '';
            this.classList.add('loading');
            ajax(page);
        }
    });
})