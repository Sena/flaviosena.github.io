<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
wp_body_open();
?>
<header>
    <nav class="navbar navbar-default">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle">
                    <label for="menu-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </label>
                </button>
                <a class="navbar-brand" href="#">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/svg/brand.svg" alt="Logo Veja"
                         title="Logo Veja">
                </a>
            </div>
            <input type="checkbox" class="toggle" id="menu-toggle"/>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
	                <?php
	                if ( has_nav_menu( 'primary' ) ) : ?>
		                <?php
		                wp_nav_menu(
			                array(
				                'container'      => '',
				                'items_wrap'     => '%3$s',
				                'theme_location' => 'primary',
			                )
		                );
		                ?>
	                <?php else: ?>
                        <li><a href="#">Diálogos vazados</a></li>
                        <li><a href="#">Previdência</a></li>
                        <li><a href="#">Radar</a></li>
                        <li><a href="#">Páginas Amareleas</a></li>
                        <li><a href="#">Revista</a></li>
                        <li><a href="#">Newsletter</a></li>
                        <li><a href="#">Podcasts</a></li>
	                <?php endif; ?>
                </ul>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container -->
    </nav>
</header>