<?php get_header(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h1>Últimas noticias</h1>
				<?php $data = senaveja_load_post(); ?>
				<?php if ( $data->total === 0 ): ?>
                    <h2>Nenhuma notícia cadastrada</h2>
				<?php else: ?>
                    <div class="post-list">
						<?php foreach ( $data->posts as $post ): ?>
                            <div class="post post-<?php echo $post->ID; ?>">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <a href="<?php echo $post->URL; ?>" target="_blank">
                                            <img src="<?php echo $post->image; ?>"
                                                 alt="<?php echo $post->title; ?>" title="<?php echo $post->title; ?>"
                                                 class="thumbnail">
                                        </a>
                                    </div>
                                    <div class="col-sm-6 info">
                                        <span class="category"><?php echo $post->category; ?></span>
                                        <a href="<?php echo $post->URL; ?>" target="_blank">
                                            <h2><?php echo $post->title; ?></h2>
                                        </a>
                                        <div class="datetime"><?php echo $post->date; ?></div>
                                    </div>
                                </div>
                            </div>
						<?php endforeach; ?>
                    </div>
					<?php if ( ! empty( $data->next ) ): ?>
                        <div class="load-more"><a href="javascript:;" data-next="<?php echo $data->next; ?>"></a></div>
					<?php endif; ?>
				<?php endif; ?>
            </div>
            <div class="col-md-4">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/box.jpg" alt="Caixa vazia"
                     title="Caixa vazia" class="empty-box">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/box.jpg" alt="Caixa vazia"
                     title="Caixa vazia" class="empty-box">
            </div>
        </div>
    </div>
<?php
get_footer();