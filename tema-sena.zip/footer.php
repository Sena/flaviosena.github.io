    <footer>
        <div class="container">
            <div class="row">
                <div class="col-sm-7">
                    <div class="copyright"></div>
                    © Abril Mídia S A. Todos os direitos reservados.
                </div>
                <div class="col-sm-5">
                    <div class="powered-by-wordpress">
                        Powered by <a href="">WordPress.com VIP</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
